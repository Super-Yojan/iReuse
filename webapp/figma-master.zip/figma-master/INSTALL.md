### [Figma](https://www.figma.com)

#### Install manually

Download using the [GitHub .zip download](https://github.com/dracula/figma/archive/master.zip) option and unzip them.

#### Using theme

1. Import `Dracula.fig` file
2. Be creative :)